{{/*
Expand the name of the chart.
*/}}
{{- define "nvidia-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "nvidia-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "nvidia-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "nvidia-operator.labels" -}}
helm.sh/chart: {{ include "nvidia-operator.chart" . }}
{{ include "nvidia-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
carbon-kube.io/component: gpu-operator
{{- end }}

{{/*
Selector labels
*/}}
{{- define "nvidia-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "nvidia-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "nvidia-operator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "nvidia-operator.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
GPU node selector
*/}}
{{- define "nvidia-operator.nodeSelector" -}}
{{- if .Values.nodeSelector }}
{{- toYaml .Values.nodeSelector }}
{{- else }}
accelerator: nvidia
{{- end }}
{{- end }}

{{/*
GPU tolerations
*/}}
{{- define "nvidia-operator.tolerations" -}}
{{- if .Values.tolerations }}
{{- toYaml .Values.tolerations }}
{{- else }}
- key: nvidia.com/gpu
  operator: Exists
  effect: NoSchedule
{{- end }}
{{- end }}